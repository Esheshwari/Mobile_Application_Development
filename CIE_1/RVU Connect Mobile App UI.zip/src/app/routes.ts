import { createBrowserRouter } from "react-router";
import { SplashScreen } from "./screens/splash-screen";
import { LoginScreen } from "./screens/login-screen";
import { HomeScreen } from "./screens/home-screen";
import { TransportScreen } from "./screens/transport-screen";
import { AnnouncementsScreen } from "./screens/announcements-screen";
import { DiningScreen } from "./screens/dining-screen";
import { CampusMapScreen } from "./screens/campus-map-screen";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: SplashScreen,
  },
  {
    path: "/login",
    Component: LoginScreen,
  },
  {
    path: "/home",
    Component: HomeScreen,
  },
  {
    path: "/transport",
    Component: TransportScreen,
  },
  {
    path: "/announcements",
    Component: AnnouncementsScreen,
  },
  {
    path: "/dining",
    Component: DiningScreen,
  },
  {
    path: "/map",
    Component: CampusMapScreen,
  },
]);
