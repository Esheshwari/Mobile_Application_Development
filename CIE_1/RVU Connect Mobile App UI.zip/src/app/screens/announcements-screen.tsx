import { useNavigate } from "react-router";
import { ArrowLeft, Bell, Calendar, ChevronRight } from "lucide-react";

export function AnnouncementsScreen() {
  const navigate = useNavigate();

  const announcements = [
    {
      title: "Campus Fest 2026",
      date: "Feb 24, 2026",
      description:
        "Annual campus festival starts next week. Register your team for various cultural and technical events.",
      priority: "high",
    },
    {
      title: "Library Hours Extended",
      date: "Feb 23, 2026",
      description:
        "Due to upcoming exams, library will be open 24/7 starting from next Monday.",
      priority: "medium",
    },
    {
      title: "Guest Lecture: AI & Machine Learning",
      date: "Feb 22, 2026",
      description:
        "Industry expert Dr. Sarah Johnson will deliver a guest lecture on latest trends in AI. Auditorium A, 2 PM.",
      priority: "medium",
    },
    {
      title: "Cafeteria Menu Update",
      date: "Feb 21, 2026",
      description:
        "New healthy food options added to the menu. Check out our fresh salad bar and smoothie station.",
      priority: "low",
    },
    {
      title: "Sports Tournament Registration",
      date: "Feb 20, 2026",
      description:
        "Inter-department cricket tournament. Last date to register is this Friday. Limited slots available.",
      priority: "medium",
    },
    {
      title: "Campus Network Maintenance",
      date: "Feb 19, 2026",
      description:
        "WiFi services will be temporarily unavailable on Saturday from 2 AM to 6 AM for scheduled maintenance.",
      priority: "high",
    },
  ];

  return (
    <div className="min-h-screen w-full max-w-[430px] mx-auto bg-gray-50">
      {/* Header */}
      <div className="bg-purple-500 px-6 pt-14 pb-6 rounded-b-[32px] shadow-lg">
        <div className="flex items-center gap-4 mb-4">
          <button
            onClick={() => navigate("/home")}
            className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center hover:bg-white/30 transition-colors"
          >
            <ArrowLeft className="w-6 h-6 text-white" />
          </button>
          <h1 className="text-2xl font-bold text-white">Announcements</h1>
        </div>
        <p className="text-purple-100 pl-14">Stay updated with campus news</p>
      </div>

      {/* Announcements List */}
      <div className="px-6 mt-6 pb-8 space-y-3">
        {announcements.map((announcement, index) => (
          <button
            key={index}
            className="w-full bg-white rounded-2xl p-5 shadow-sm hover:shadow-md transition-all active:scale-[0.98] text-left"
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-start gap-3 flex-1">
                <div
                  className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${
                    announcement.priority === "high"
                      ? "bg-red-100"
                      : announcement.priority === "medium"
                      ? "bg-purple-100"
                      : "bg-blue-100"
                  }`}
                >
                  <Bell
                    className={`w-5 h-5 ${
                      announcement.priority === "high"
                        ? "text-red-500"
                        : announcement.priority === "medium"
                        ? "text-purple-500"
                        : "text-blue-500"
                    }`}
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold text-gray-900 mb-1 line-clamp-1">
                    {announcement.title}
                  </h3>
                  <div className="flex items-center gap-2 mb-2">
                    <Calendar className="w-4 h-4 text-gray-400" />
                    <span className="text-sm text-gray-500">{announcement.date}</span>
                  </div>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400 ml-2 flex-shrink-0" />
            </div>
            <p className="text-sm text-gray-600 leading-relaxed line-clamp-2 pl-13">
              {announcement.description}
            </p>
          </button>
        ))}
      </div>
    </div>
  );
}
