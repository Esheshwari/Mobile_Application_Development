import { useNavigate } from "react-router";
import { Bus, Bell, Utensils, Map, ChevronRight } from "lucide-react";

export function HomeScreen() {
  const navigate = useNavigate();

  const cards = [
    {
      title: "Transport",
      icon: Bus,
      color: "bg-blue-500",
      path: "/transport",
    },
    {
      title: "Announcements",
      icon: Bell,
      color: "bg-purple-500",
      path: "/announcements",
    },
    {
      title: "Dining Status",
      icon: Utensils,
      color: "bg-green-500",
      path: "/dining",
    },
    {
      title: "Campus Map",
      icon: Map,
      color: "bg-orange-500",
      path: "/map",
    },
  ];

  return (
    <div className="min-h-screen w-full max-w-[430px] mx-auto bg-gray-50">
      {/* Header */}
      <div className="bg-blue-500 px-6 pt-16 pb-8 rounded-b-[32px] shadow-lg">
        <h1 className="text-3xl font-bold text-white mb-1">Welcome, Student</h1>
        <p className="text-blue-100">Tuesday, February 24, 2026</p>
      </div>

      {/* Cards Grid */}
      <div className="px-6 mt-8 pb-8">
        <div className="grid grid-cols-2 gap-4">
          {cards.map((card) => {
            const Icon = card.icon;
            return (
              <button
                key={card.title}
                onClick={() => navigate(card.path)}
                className="bg-white rounded-2xl p-6 shadow-sm hover:shadow-md transition-all active:scale-95 flex flex-col items-center justify-center gap-4 aspect-square"
              >
                <div className={`${card.color} w-14 h-14 rounded-2xl flex items-center justify-center`}>
                  <Icon className="w-7 h-7 text-white" strokeWidth={2} />
                </div>
                <div className="text-center">
                  <h3 className="font-semibold text-gray-900">{card.title}</h3>
                </div>
              </button>
            );
          })}
        </div>

        {/* Quick Actions */}
        <div className="mt-8 bg-white rounded-2xl shadow-sm overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-100">
            <h2 className="font-semibold text-gray-900">Quick Actions</h2>
          </div>
          <button className="w-full px-6 py-4 flex items-center justify-between hover:bg-gray-50 transition-colors active:bg-gray-100">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center">
                <Bus className="w-5 h-5 text-blue-500" />
              </div>
              <span className="text-gray-700">Check Bus Schedule</span>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-400" />
          </button>
          <button className="w-full px-6 py-4 flex items-center justify-between hover:bg-gray-50 transition-colors active:bg-gray-100">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-purple-100 rounded-xl flex items-center justify-center">
                <Bell className="w-5 h-5 text-purple-500" />
              </div>
              <span className="text-gray-700">Latest Announcements</span>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-400" />
          </button>
        </div>
      </div>
    </div>
  );
}
