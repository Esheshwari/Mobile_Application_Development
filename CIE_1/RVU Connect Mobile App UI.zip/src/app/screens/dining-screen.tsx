import { useNavigate } from "react-router";
import { ArrowLeft, Utensils, Users, TrendingUp, TrendingDown, Minus } from "lucide-react";
import { Progress } from "../components/ui/progress";

export function DiningScreen() {
  const navigate = useNavigate();

  const diningHalls = [
    {
      name: "Main Cafeteria",
      crowdLevel: "Low",
      capacity: 25,
      color: "green",
      trend: "down",
    },
    {
      name: "North Block Canteen",
      crowdLevel: "Medium",
      capacity: 60,
      color: "yellow",
      trend: "stable",
    },
    {
      name: "Food Court",
      crowdLevel: "High",
      capacity: 85,
      color: "red",
      trend: "up",
    },
    {
      name: "Library Cafe",
      crowdLevel: "Low",
      capacity: 30,
      color: "green",
      trend: "down",
    },
    {
      name: "Sports Complex Snack Bar",
      crowdLevel: "Medium",
      capacity: 55,
      color: "yellow",
      trend: "up",
    },
  ];

  const getCrowdColor = (level: string) => {
    switch (level) {
      case "Low":
        return {
          bg: "bg-green-50",
          text: "text-green-600",
          badge: "bg-green-100",
          progress: "bg-green-500",
        };
      case "Medium":
        return {
          bg: "bg-yellow-50",
          text: "text-yellow-600",
          badge: "bg-yellow-100",
          progress: "bg-yellow-500",
        };
      case "High":
        return {
          bg: "bg-red-50",
          text: "text-red-600",
          badge: "bg-red-100",
          progress: "bg-red-500",
        };
      default:
        return {
          bg: "bg-gray-50",
          text: "text-gray-600",
          badge: "bg-gray-100",
          progress: "bg-gray-500",
        };
    }
  };

  return (
    <div className="min-h-screen w-full max-w-[430px] mx-auto bg-gray-50">
      {/* Header */}
      <div className="bg-green-500 px-6 pt-14 pb-6 rounded-b-[32px] shadow-lg">
        <div className="flex items-center gap-4 mb-4">
          <button
            onClick={() => navigate("/home")}
            className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center hover:bg-white/30 transition-colors"
          >
            <ArrowLeft className="w-6 h-6 text-white" />
          </button>
          <h1 className="text-2xl font-bold text-white">Dining Status</h1>
        </div>
        <p className="text-green-100 pl-14">Real-time crowd information</p>
      </div>

      {/* Info Card */}
      <div className="px-6 mt-6">
        <div className="bg-blue-50 rounded-2xl p-4 flex items-start gap-3">
          <div className="w-10 h-10 bg-blue-500 rounded-xl flex items-center justify-center flex-shrink-0">
            <Users className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900 mb-1">Live Updates</h3>
            <p className="text-sm text-gray-600">
              Crowd levels are updated every 5 minutes to help you plan your visit.
            </p>
          </div>
        </div>
      </div>

      {/* Dining Halls List */}
      <div className="px-6 mt-6 pb-8 space-y-4">
        {diningHalls.map((hall, index) => {
          const colors = getCrowdColor(hall.crowdLevel);
          return (
            <div
              key={index}
              className="bg-white rounded-2xl p-5 shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className={`w-12 h-12 ${colors.bg} rounded-xl flex items-center justify-center`}>
                    <Utensils className={`w-6 h-6 ${colors.text}`} />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900">{hall.name}</h3>
                    <div className="flex items-center gap-2 mt-1">
                      <span className={`text-xs font-semibold ${colors.text}`}>
                        {hall.crowdLevel} Crowd
                      </span>
                      {hall.trend === "up" && (
                        <TrendingUp className="w-4 h-4 text-red-500" />
                      )}
                      {hall.trend === "down" && (
                        <TrendingDown className="w-4 h-4 text-green-500" />
                      )}
                      {hall.trend === "stable" && (
                        <Minus className="w-4 h-4 text-gray-400" />
                      )}
                    </div>
                  </div>
                </div>
                <div
                  className={`px-3 py-1 rounded-full ${colors.badge} ${colors.text} text-xs font-semibold`}
                >
                  {hall.capacity}%
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Capacity</span>
                  <span className="font-semibold text-gray-900">{hall.capacity}%</span>
                </div>
                <div className="relative h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div
                    className={`absolute inset-y-0 left-0 ${colors.progress} transition-all duration-500`}
                    style={{ width: `${hall.capacity}%` }}
                  />
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
