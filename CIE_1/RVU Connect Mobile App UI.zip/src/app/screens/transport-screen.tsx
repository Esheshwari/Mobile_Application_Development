import { useNavigate } from "react-router";
import { ArrowLeft, Bus, Clock, MapPin, CheckCircle2, AlertCircle } from "lucide-react";

export function TransportScreen() {
  const navigate = useNavigate();

  const buses = [
    {
      busNumber: "Bus 101",
      route: "Main Campus - North Gate",
      pickupTime: "09:15 AM",
      status: "On Time",
      isDelayed: false,
    },
    {
      busNumber: "Bus 202",
      route: "Main Campus - South Gate",
      pickupTime: "09:30 AM",
      status: "On Time",
      isDelayed: false,
    },
    {
      busNumber: "Bus 303",
      route: "Main Campus - East Gate",
      pickupTime: "09:45 AM",
      status: "Delayed",
      isDelayed: true,
    },
    {
      busNumber: "Bus 404",
      route: "Library - Hostel Block",
      pickupTime: "10:00 AM",
      status: "On Time",
      isDelayed: false,
    },
    {
      busNumber: "Bus 505",
      route: "Sports Complex - Main Gate",
      pickupTime: "10:15 AM",
      status: "On Time",
      isDelayed: false,
    },
  ];

  return (
    <div className="min-h-screen w-full max-w-[430px] mx-auto bg-gray-50">
      {/* Header */}
      <div className="bg-blue-500 px-6 pt-14 pb-6 rounded-b-[32px] shadow-lg">
        <div className="flex items-center gap-4 mb-4">
          <button
            onClick={() => navigate("/home")}
            className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center hover:bg-white/30 transition-colors"
          >
            <ArrowLeft className="w-6 h-6 text-white" />
          </button>
          <h1 className="text-2xl font-bold text-white">Transport</h1>
        </div>
        <p className="text-blue-100 pl-14">Live bus schedules and routes</p>
      </div>

      {/* Bus List */}
      <div className="px-6 mt-6 pb-8 space-y-4">
        {buses.map((bus, index) => (
          <div
            key={index}
            className="bg-white rounded-2xl p-5 shadow-sm hover:shadow-md transition-shadow"
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                  <Bus className="w-6 h-6 text-blue-500" />
                </div>
                <div>
                  <h3 className="font-bold text-gray-900">{bus.busNumber}</h3>
                  <p className="text-sm text-gray-500">Campus Transport</p>
                </div>
              </div>
              <div
                className={`px-3 py-1 rounded-full flex items-center gap-1.5 ${
                  bus.isDelayed
                    ? "bg-red-50 text-red-600"
                    : "bg-green-50 text-green-600"
                }`}
              >
                {bus.isDelayed ? (
                  <AlertCircle className="w-4 h-4" />
                ) : (
                  <CheckCircle2 className="w-4 h-4" />
                )}
                <span className="text-xs font-semibold">{bus.status}</span>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <MapPin className="w-5 h-5 text-gray-400 flex-shrink-0" />
                <span className="text-gray-700">{bus.route}</span>
              </div>
              <div className="flex items-center gap-3">
                <Clock className="w-5 h-5 text-gray-400 flex-shrink-0" />
                <span className="text-gray-700">Pickup: {bus.pickupTime}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
