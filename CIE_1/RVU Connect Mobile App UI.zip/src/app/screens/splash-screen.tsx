import { useEffect } from "react";
import { useNavigate } from "react-router";
import { GraduationCap } from "lucide-react";

export function SplashScreen() {
  const navigate = useNavigate();

  useEffect(() => {
    const timer = setTimeout(() => {
      navigate("/login");
    }, 2500);
    return () => clearTimeout(timer);
  }, [navigate]);

  return (
    <div className="h-screen w-full max-w-[430px] mx-auto bg-gradient-to-br from-blue-400 via-blue-500 to-blue-600 flex flex-col items-center justify-center px-6">
      <div className="flex flex-col items-center gap-8 animate-in fade-in duration-700">
        {/* Logo */}
        <div className="w-28 h-28 bg-white rounded-3xl flex items-center justify-center shadow-2xl">
          <GraduationCap className="w-16 h-16 text-blue-500" strokeWidth={2} />
        </div>
        
        {/* App Name */}
        <h1 className="text-5xl font-bold text-white tracking-tight">
          RVU Connect
        </h1>
        
        {/* Tagline */}
        <p className="text-xl text-blue-50 font-light tracking-wide">
          Your Campus, One Tap Away
        </p>
      </div>
    </div>
  );
}
