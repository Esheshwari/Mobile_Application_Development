import { useNavigate } from "react-router";
import { ArrowLeft, MapPin, Building2, GraduationCap, Coffee, BookOpen, Dumbbell } from "lucide-react";

export function CampusMapScreen() {
  const navigate = useNavigate();

  const locations = [
    { name: "Main Building", icon: Building2, x: 30, y: 25, color: "bg-blue-500" },
    { name: "Library", icon: BookOpen, x: 60, y: 35, color: "bg-purple-500" },
    { name: "Sports Complex", icon: Dumbbell, x: 75, y: 60, color: "bg-green-500" },
    { name: "Academic Block", icon: GraduationCap, x: 25, y: 55, color: "bg-orange-500" },
    { name: "Cafeteria", icon: Coffee, x: 50, y: 70, color: "bg-red-500" },
  ];

  return (
    <div className="min-h-screen w-full max-w-[430px] mx-auto bg-gray-50">
      {/* Header */}
      <div className="bg-orange-500 px-6 pt-14 pb-6 rounded-b-[32px] shadow-lg">
        <div className="flex items-center gap-4 mb-4">
          <button
            onClick={() => navigate("/home")}
            className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center hover:bg-white/30 transition-colors"
          >
            <ArrowLeft className="w-6 h-6 text-white" />
          </button>
          <h1 className="text-2xl font-bold text-white">Campus Map</h1>
        </div>
        <p className="text-orange-100 pl-14">Navigate your campus easily</p>
      </div>

      {/* Map Container */}
      <div className="px-6 mt-6 pb-8">
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
          {/* Map Area */}
          <div className="relative bg-gradient-to-br from-green-50 via-blue-50 to-purple-50 aspect-square">
            {/* Campus Paths */}
            <svg className="absolute inset-0 w-full h-full" style={{ zIndex: 1 }}>
              <path
                d="M 30 25 Q 45 30, 60 35"
                stroke="#94a3b8"
                strokeWidth="3"
                fill="none"
                strokeDasharray="5,5"
              />
              <path
                d="M 60 35 Q 70 50, 75 60"
                stroke="#94a3b8"
                strokeWidth="3"
                fill="none"
                strokeDasharray="5,5"
              />
              <path
                d="M 30 25 Q 27 40, 25 55"
                stroke="#94a3b8"
                strokeWidth="3"
                fill="none"
                strokeDasharray="5,5"
              />
              <path
                d="M 25 55 Q 37 62, 50 70"
                stroke="#94a3b8"
                strokeWidth="3"
                fill="none"
                strokeDasharray="5,5"
              />
              <path
                d="M 60 35 Q 55 52, 50 70"
                stroke="#94a3b8"
                strokeWidth="3"
                fill="none"
                strokeDasharray="5,5"
              />
            </svg>

            {/* Location Pins */}
            {locations.map((location, index) => {
              const Icon = location.icon;
              return (
                <div
                  key={index}
                  className="absolute transform -translate-x-1/2 -translate-y-1/2 animate-in fade-in zoom-in duration-500"
                  style={{
                    left: `${location.x}%`,
                    top: `${location.y}%`,
                    zIndex: 2,
                    animationDelay: `${index * 100}ms`,
                  }}
                >
                  <div className="relative group cursor-pointer">
                    {/* Pin */}
                    <div className={`${location.color} w-12 h-12 rounded-full shadow-lg flex items-center justify-center border-4 border-white transform transition-transform hover:scale-110`}>
                      <Icon className="w-6 h-6 text-white" strokeWidth={2} />
                    </div>
                    {/* Pulse Effect */}
                    <div className={`absolute inset-0 ${location.color} rounded-full opacity-30 animate-ping`} />
                    {/* Label */}
                    <div className="absolute top-full mt-2 left-1/2 transform -translate-x-1/2 bg-gray-900 text-white text-xs font-medium px-3 py-1.5 rounded-lg whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity shadow-lg">
                      {location.name}
                      <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-b-4 border-transparent border-b-gray-900" />
                    </div>
                  </div>
                </div>
              );
            })}

            {/* Decorative Elements */}
            <div className="absolute top-4 right-4 bg-white/80 backdrop-blur-sm px-3 py-2 rounded-lg shadow-sm text-xs font-medium text-gray-700">
              RVU Campus
            </div>
          </div>

          {/* Legend */}
          <div className="p-5 bg-gray-50 border-t border-gray-200">
            <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
              <MapPin className="w-5 h-5 text-gray-600" />
              Key Locations
            </h3>
            <div className="grid grid-cols-2 gap-3">
              {locations.map((location, index) => {
                const Icon = location.icon;
                return (
                  <div key={index} className="flex items-center gap-2">
                    <div className={`${location.color} w-8 h-8 rounded-lg flex items-center justify-center`}>
                      <Icon className="w-4 h-4 text-white" strokeWidth={2} />
                    </div>
                    <span className="text-sm text-gray-700">{location.name}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Info Card */}
        <div className="mt-4 bg-blue-50 rounded-2xl p-4 flex items-start gap-3">
          <div className="w-10 h-10 bg-blue-500 rounded-xl flex items-center justify-center flex-shrink-0">
            <MapPin className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900 mb-1">Interactive Map</h3>
            <p className="text-sm text-gray-600">
              Tap on any location pin to see more details and get directions.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
