
  # RVU Connect Mobile App UI

  This is a code bundle for RVU Connect Mobile App UI. The original project is available at https://www.figma.com/design/u6CEFFvvdCdGKbsIRjSdH4/RVU-Connect-Mobile-App-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  